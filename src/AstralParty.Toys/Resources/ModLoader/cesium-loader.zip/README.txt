cesium-loader-3.8.9
- version.dll                          → 复制到游戏 exe 目录 (Doorstop 式代理加载器)
- CHANGELOG.md                         → 更新日志(Toys 用它做离线兜底)
- AstralParty_ModLoader\doorstop_config.json → 加载器配置 (enabled=false 可完全禁用)
- AstralParty_ModLoader\bootstrap\     → 托管引导程序 (先于 SDK/mods 加载)
- AstralParty_ModLoader\sdk\           → SDK 依赖
- AstralParty_ModLoader\mods\          → 用户 mod (每 mod 一个文件夹: mods\{ModId}\{ModId}.dll)
- AstralParty_ModLoader\mods\{ModId}\{ModId}.json → mod sidecar (id/版本/权限/enabled 开关/依赖)
- *.pdb (version / bootstrap / sdk / mods\*) → 符号文件(与同名 dll 配对): 把崩溃栈还原成文件行号用, 删掉不影响运行
- AstralParty_ModLoader\sdk\CesiumLoader.SDK.xml → SDK 的 XML 文档(与 dll 同名): 写 mod 时 IDE 里可见类型/成员注释, 删掉不影响运行
  随包内置: 
mods\ActivityLogMod (行为日志) / mods\FreeCameraMod (自由相机, 滚轮缩放(视角不变) / F1 恢复原视角) / mods\SpeedHackMod (变速, Delete 开关 / Alt+= Alt+- 调倍率) / mods\TurnClockMod (TurnClockMod) / mods\CombatOddsMod (CombatOddsMod) / mods\CardSkinMod (CardSkinMod) / mods\AudioSkinMod (AudioSkinMod) / mods\AutoThanksMod (AutoThanksMod) / mods\ForkDirectionMod (ForkDirectionMod) / mods\TurnFocusMod (回合置前, 轮到自己时把游戏窗口切到前台, 可选播放提示音) / mods\HideHudMod (隐藏HUD, 长按反引号(Tab 上方)隐藏战斗 HUD, 可改为按一下切换) / mods\QuickChatPlusMod (快捷短语扩展, 战斗内快捷短语补全并支持滚动) / mods\ChatDurationMod (消息停留时间, 战斗消息与表情按真实时间停留, 不受变速影响) / mods\HomeBottomBarMod (主页底栏调整, 隐藏公告 / 设置左移 / 右侧增加退出按钮) / mods\UnlockFrameRateMod (帧率解锁, 帧率列表追加 144/165/240/360/不限帧) / mods\LanguageUnlockMod (多语言支持, 国服启用英文/日文/繁中语言选项) / mods\PveWaveForecastMod (PveWaveForecastMod) / mods\StarCoinShopMod (StarCoinShopMod) / mods\CharacterTransparencyMod (CharacterTransparencyMod) / mods\ShopRelicPeekMod (ShopRelicPeekMod) / mods\MapPeekMod (MapPeekMod) / mods\PinnedRelicsMod (PinnedRelicsMod) / mods\PvePanelMod (PvePanelMod) / mods\AngelModeUnlockMod (AngelModeUnlockMod) / mods\UpdateNoticeMod (加载器更新提示, 发现新版本时在游戏内弹面板) / mods\FontMod (FontMod)
TurnFocusMod 默认不播放提示音; 在 mods\TurnFocusMod\config.json 的 soundFile 填 WAV 路径后启用(随包示例 sounds\your-turn.wav)。
AutoThanksMod 默认启用: 队友治疗、给牌或转星币给你时自动发送原版感谢短语，默认 2 秒真实时间冷却。
HideHudMod 默认启用: 长按反引号键（Tab 上方）隐藏战斗 HUD，松开恢复；可在 config.json 改成按一下切换，并分别开关手牌、怪物信息、头像与其他 HUD。
ChatDurationMod 默认启用: 战斗中的快捷消息与表情按真实时间停留 15 秒(可在 config.json 调整)，变速不会缩短停留时间。
HomeBottomBarMod 默认启用: 主页底栏隐藏公告，设置左移一位，最右侧增加退出按钮（沿用游戏原生退出确认）。
UnlockFrameRateMod 默认启用: 在游戏「设置→屏幕→帧率」列表追加 144/165/240/360/不限帧 选项，选中后由游戏自己应用。
LanguageUnlockMod 默认启用: 国服在游戏「设置→屏幕→语言」里启用英文 / 日文 / 繁中；国际服原生支持，模组自动不介入。
- AstralParty_ModLoader\logs\          → 日志目录
- CesiumLoader-NOTICE.txt / CesiumLoader-LICENSE.txt → 版权声明与 AGPL-3.0 全文
  (游戏 exe 目录与 AstralParty_ModLoader 各一份; 安装即表示同意该协议)
解压到游戏 exe 目录即完成安装。
默认皮肤单独提供: cesium-default-skins.zip，解压到同一游戏 exe 目录。
加载器包包含 CardSkinMod，但不包含 skins；未安装皮肤时使用游戏原图。
从旧版升级: 请删除游戏目录下的 winmm.dll (旧代理), 换成 version.dll。
⚠ 与本加载器互斥: 旧版独立变速器也使用 version.dll(speedhack-rs) —— 不要同时安装!
  CesiumLoader 已内置变速引擎(加载器功能, 非 mod): 改 doorstop_config.json 的
  speedhackBaseSpeed 即可(2.0=全程2倍速, 1.0=正常), 或直接用 AstralParty.Toys 的模组页面开关。
  游戏内实时调整: 内置 mod 变速(SpeedHackMod) —— Delete 开关, Alt+= / Alt+- 调倍率。
