# 更新日志 / Changelog

本文件按版本记录 `CesiumLoader` 的功能变更。版本号与 GitHub 发布 tag 一一对应（如 `modloader-3.3.2`，版本号为 `3.3.2`），发布产物由 [release-modloader.yml](.github/workflows/release-modloader.yml) 在打 tag 时自动构建。

## [3.8.9] - 2026-11-20

### 加载器

- 修复游戏安装在非 ASCII（如中文）目录时模组无法加载的问题。模组目录扫描、`{ModId}.json` 元数据读取与模组 DLL 读取统一改用宽字符路径，不再依赖系统 ANSI 代码页；此前安装路径含中文时会出现 `dll read failed` 或元数据解析失败，表现为模组一个也加载不出来。

### 构建与打包

- SDK 的 `Version` / `FileVersion`、`SdkVersion.Current` / `LoaderVersion`、原生加载器 `loaderVersion` 与分发模板 `doorstop_config.json` 的 `sdkVersion` 同步到 `3.8.9`。

## [3.8.8] - 2026-11-19

### 模组

- `FontMod`（系统字体）修复了「选了字体却仍显示系统默认字体」的问题。字体列表现在以游戏自身识别的字体为准，选择后立即生效；无法识别的字体名会被跳过并保留游戏默认字体，不再出现选了没变化的情况。
- 加载器自绘的面板（如 F8 更新提示、PVE 面板）现在跟随所选字体。

### SDK

- `WidgetService.SetDefaultFont(object)` 允许模组把已校验的字体提供给自绘面板使用。

### 构建与打包

- SDK 的 `Version` / `FileVersion`、`SdkVersion.Current` / `LoaderVersion`、原生加载器 `loaderVersion` 与分发模板 `doorstop_config.json` 的 `sdkVersion` 同步到 `3.8.8`。

## [3.8.7] - 2026-11-17

### 模组

- 新增内置模组 `FontMod 1.0.0`（系统字体）：把游戏旧版界面字体替换成系统已安装的字体，支持按字重独立命名的变体（如 `Microsoft YaHei UI Light`）与多语言回退；在 Toys「自定义 → 字体」里选择，配置热重载即时生效。
- 替换前按游戏文案字符集检查缺字，缺字过多时保持默认字体并记录缺字，避免方块；`config.json` 的 `checkCoverage` 可关闭检查，`fallbackFonts` 可补充回退字体。
- `tools/builtin-mods.json` 与 Toys 内置分发清单加入 `FontMod`。

### 构建与打包

- SDK 的 `Version` / `FileVersion`、`SdkVersion.Current` / `LoaderVersion`、原生加载器 `loaderVersion` 与分发模板 `doorstop_config.json` 的 `sdkVersion` 同步到 `3.8.7`。

## [3.8.6] - 2026-11-16

### 模组

- `FreeCameraMod` 2.7.1 → 2.7.2：移除「点击怪物头像时还原缩放/旋转」开关（`restoreOnMonsterFocus`）。该行为已停用，镜头切换交回游戏自己处理；老配置里的该键在加载时自动清除。

## [3.8.5] - 2026-11-16

### 更新检查（加载器 + 游戏内提示）

- 加载器启动后在后台线程拉取 Release 的静态 `version.json`（不请求 GitHub API，无配额与鉴权），直连失败自动回退 `gh-proxy` 镜像；结果写入 `update/state.json`，控制台以绿色输出一行 `[update]`。
- 新增配置：`updateCheckEnabled`、`updateCheckUrl`、`updateCheckMirror`、`updateCheckIntervalHours`、`updateCheckTimeoutSec`。默认 6 小时内不重复联网（复用上次结果）、单条请求 8 秒超时；取值范围越界按默认值处理。
- Debug Shell 新增 `update` 命令：`update` 查看结论与发布页、`update check` 忽略冷却强制重查、`update open` 用默认浏览器打开发布页；`status` 增加「更新」一行。
- 新增内置模组 `UpdateNoticeMod 1.0.0`（加载器更新提示）：发现新版本时在游戏内弹面板，显示当前/最新版本与发布页，提供「打开发布页」「忽略此版本」「稍后再看」，热键 `F8`。模组自身不联网，只读状态文件，并通过本地 UDP 请求加载器执行打开浏览器/重新检查。

### SDK

- 新增 `CesiumLoader.SDK.Updates.UpdateCheck` / `UpdateCheckState`：读取检查结果、请求重新检查、打开发布页（见 [SDK-UpdateCheck](docs/SDK-UpdateCheck.md)）。
- `WidgetService` 新增 `Button` / `SetOnClick` / `IsButtonAvailable`，可在 mod 面板里放置可点击按钮，缺 uGUI 类型时安全退回键盘交互。
- `WidgetService.Place` 现在会把 `pivot` 对齐到锚点所在的角/边。此前只设锚点、pivot 仍是中心，`position` 变成「矩形中心离锚点多远」，顶部元素会向上溢出、相邻两行叠在一起。

### 构建与打包

- SDK 的 `Version` / `FileVersion`、`SdkVersion.Current` / `LoaderVersion` 与加载器版本同步到 `3.8.5`。
- `tools/builtin-mods.json` 与 Toys 内置分发清单加入 `UpdateNoticeMod`。

## [3.8.3] - 2026-11-15

### 内置 PVE 面板更新（PvePanelMod 0.3.1）

- 右栏情报栏视觉与交互优化：彩色表示被选走或拿走，进行中已购买的卡牌增加绿色细边框，结束后未选中的筹码与卡牌转为黑白灰度；移除深色遮罩与打勾图标。
- 界面布局与层级避让：右栏位置调整至右上角表情按钮左侧，UI 层级置于表情与聊天窗口之下，避免遮挡原生交互与聊天窗口。
- 战斗面板与显示兼容：
  - 玩家昵称截断前先剥离 UBB 富文本标签，避免炫彩 ID 格式损坏。
  - 战斗面板布局避开战斗手牌点数显示区域。
  - 兼容隐藏队友昵称等单位过滤场景，按单位类型排除怪物单位。
- 模组版本更新为 `0.3.1`。

### 构建与打包

- SDK 的 `Version` / `FileVersion`、`SdkVersion.Current` / `LoaderVersion` 与加载器版本同步到 `3.8.3`。

## [3.8.2] - 2026-11-15

### 内置多语言支持更新（LanguageUnlockMod 1.0.2）

- 从最新国际服客户端提取并更新全部英 / 日 / 繁语言资源（62 张 STR 表共 23,256 条文本，以及 FairyGUI 界面文案包）。
- 模组版本更新为 `1.0.2`。

### 构建与打包

- SDK 的 `Version` / `FileVersion`、`SdkVersion.Current` / `LoaderVersion` 与加载器版本同步到 `3.8.2`。

## [3.8.1] - 2026-11-15

### 平台声明：模组可以标注只支持 Windows 或 Android

- `ModManifestAttribute` 新增 `Platforms`，与 `Permissions` 一样按位声明：`Platforms = ModPlatform.Windows | ModPlatform.Android`；缺省（`ModPlatform.None`）= 两个平台都支持，旧模组与第三方模组不写这个字段也能照常加载。
- sidecar 落盘为字符串数组 `"platforms":["windows","android"]`（只写已知取值、去重、Windows 在前）；`ModPlatforms` 提供 `ToNames` / `Parse` / `Normalize` / `Supports` 转换。
- 平台只用于界面标注，加载器与安卓引导都**不**按平台拦截。
- 内置模组按实际能力声明：依赖 Win32 窗口 / 进程 / 桌面端文件的 11 个模组声明 `Windows`，其余声明两个平台（含触摸手势的 `FreeCameraMod`、可配置热键的 `SpeedHackMod` / `TurnClockMod`）。
- `cesium init` 模板同时生成枚举声明与 sidecar 的 `platforms` 数组。

### 构建与打包

- SDK 的 `Version` / `FileVersion`、`SdkVersion.Current` / `LoaderVersion` 与加载器版本同步到 `3.8.1`。

## [3.8.0] - 2026-11-14

### 变速与回合时钟：没有原生加载器时也能用

- 变速的 Unity 模式不再等待原生时钟回执：检测不到原生引擎时（由托管引导加载、没有 `version.dll` 的运行环境），把原生时钟按 1x 处理并直接驱动 `Time.timeScale`。以前这种情况会被当成"引擎暂不可用"，倍率一直不生效。
- 同一环境下，`speed` 在游戏运行中改配置即生效——手机或模组管理器里改完配置不必重启游戏即可调速。
- 回合时钟的补偿倍数改为「原生倍率 × 实测帧倍率」：没有原生引擎时由帧时钟提供倍率，操作、选人、结算、房间等待与剧情自动播放仍按真实时间走。
- 有原生引擎的桌面上行为不变（`SpeedHackMod 2.5.5` / `TurnClockMod 1.4.3`）。

### PVE 面板 0.3.0

- 新增 `GridMap`（默认开）：点开官方小地图时换成 wiki 式方格图，按格子坐标对齐排列、使用游戏自己的格子图标、显示格子编号与 P1～P4 出生点，玩家 / 怪物 / Boss 头像画在所在格子上；按住地图时镜头移到手指下面那一格。关掉即恢复官方原样。
- 波次按游戏进度计算；血量一行放不下时整行等比缩小。

### SDK

- 新增 Android 平台适配层：平台探测、触摸手势、通知，以及按平台选择输入后端（安卓不构造 Win32 后端）。
- `MainThread.Run` / `Run<T>` 进入时确保主线程泵已启动，避免"只订阅、不更新"。
- 模组配置统一解析到 `configs/<ModId>.json`；旧安装里的 `mods/<ModId>/config.json` 仍可读取。

### 构建与打包

- SDK 的 `Version` / `FileVersion`、`SdkVersion.Current` / `LoaderVersion` 与加载器版本同步到 `3.8.0`。

## [3.7.6] - 2026-11-14

### 调试支持

- 新增 `debugWaitForDebugger` / `debugWaitTimeoutSec`：引导线程在开跑前等待调试器附加，检测到后主动断下，可在继续执行前下断点（默认关闭；Steam 启动的游戏无法由调试器直接启动）。
- 新增 `logLevel`：加载 SDK 与模组之前注入 `CESIUM_LOG_LEVEL`，可在 `doorstop_config.json` 或调试 Shell 里直接切到 `Debug`，不必改用户环境变量并重启 Steam。
- 新增 `crashDumpEnabled` / `crashDumpFullMemory`：访问冲突、栈溢出、堆损坏等致命原生异常时在加载器目录的 `crash\` 下写 `<会话>.dmp` 与同名说明文件。说明文件里是异常摘要与崩溃时的加载器环境（版本、路径、命令行、`GameAssembly.dll` 指纹、完整配置、模组加载结果）；dump 可直接用 Visual Studio 打开查看线程栈，有调试器附加时不落盘。
- 加载器与转发到控制台的模组日志同时镜像到调试器输出通道（Visual Studio 输出窗口、DebugView）。
- 新增 `nativeWatchdogEnabled` / `nativeWatchdogTimeoutSec`：主线程指令指针连续停滞超过阈值（且游戏窗口在前台）时，自动写 `crash\hang-<会话>.dmp` 与说明文件；卡死不产生异常，这是"游戏无响应"时唯一能取到现场的原生路径。每秒采样一次、稳态开销可忽略，默认关闭。
- 调试 Shell 新增 `dump [备注]`：立即把当前所有线程栈写一份转储到 `crash\manual-<会话>.dmp`（写入期间游戏停顿不到 1 秒），不需要崩溃，也不依赖看门狗是否开启。
- 调试 Shell 可读写上述配置项。

### 行为变更

- **Steam 绕过默认全部关闭**（`steamBypassEnabled` / `steamBypassRestartCheck` / `steamBypassMatchmaking` / `steamBypassLobbyHasValue` / `steamBypassLobbyQuery` 均为 `false`）。正常由 Steam 启动时不需要任何绕过；需要"不开 Steam 也能进游戏/建房"时再逐项打开，行为与联网语义随之改变。
- `crashDumpEnabled=false` 只是关掉致命异常的自动落盘，转储设施仍会初始化，`dump` 命令与看门狗照常可用。
- 转储目录从 `logs\crash\` 改为加载器目录下的 `crash\`（`<loader>\crash\`），避免大文件与日志混在一起；`tools\verify-crash-dump.ps1` 会自动识别新目录，旧安装的 `logs\crash\` 仍可回退读取。

### 构建与打包

- 发布产物新增 Debug 版加载器包（`cesium-loader-debug.zip` / `cesium-loader-debug-<版本>.zip`）：与正式包同布局，`version.dll` / `version.pdb` 换成 Debug 构建，并带一份用 Debug 哈希重写的 `cesium-loader.json`（`channel: debug`），因此 AstralParty.Toys 的「导入发布包」可以直接安装；`tools/package-modloader.ps1` 与发布工作流都会产出，本地可用同一脚本验证。包里的 `README.txt` 说明调试 CRT 依赖、附加调试器与转储位置（Toys 导入时不会解压 README）。

## [3.7.5] - 2026-11-13

### 新增内置模组

- **天使模式解锁（AngelModeUnlockMod 1.0.1）**：部分审核渠道把「设置 → 功能」里的天使模式开关藏了起来（编进隐藏分组、停在审核页、文案被替换），只清 `RemoteConfig` 标记看不见效果。本模组在运行时把这一行恢复出来，显示为「天使模式」并可直接点击切换；同时清除并保持 `IsAuditMode` / `IsAngelMode`，审核模式下被一并隐藏的平台信息、联动内容也按非审核行为显示。可选用 `angelMode` 固定开关状态；在开关本来就正常的客户端上是空操作。

### PVE 面板 0.2.0

- 血量改成「当前 / 上限」，一行放不下时数字一起缩小；战斗面板在左栏收起时照常显示。
- 打开自己的商店、转账（ATM）、进入自己的战斗时自动收起左栏，关掉后展开（`AutoCollapse`，别人进店、别人打架不收；原本就收起的不会被展开，窗口里手动展开过就不再收）。
- 与「关键筹码置顶」联动：读取它画在官方左栏的筹码行（`PinnedRelicsMod.Row`），按横坐标顺序在角色栏里重画一份，名单与顺序跟它的配置走；未安装时不留位置，没有编译期依赖。

### 构建与打包

- 解决方案切换为 `CesiumLoader.slnx`，README、`Directory.Build.props`、`tools/deploy.ps1` 与发布工作流同步更新。

## [3.7.4] - 2026-11-13

### 新增内置模组

- **PVE 面板（PvePanelMod 0.1.0）**：把「商店与筹码看板」「PVE 波次预告」「手牌查看」和「战斗胜率助手」的战斗读数合并成一套 PVE 界面。
  - 左侧信息栏：头像（跟随官方皮肤）、楼层色底板、血量、星币、手牌数、星级、技能冷却、buff 图标；击倒头像变灰、离线加电脑标记。
  - 右侧情报栏：下一波怪物与轮次奖励倒计时、最多 3 波波次表、一至四楼最近一次的商店与筹码。
  - 战斗面板：该防御 / 该闪避、两种选择的存活概率、击杀概率与预计伤害，接管「战斗胜率助手」的读数框，面板收起后自动恢复。
  - 手牌抽屉与悬停说明；`F3` / `F4` / `F5` 快捷键、整体缩放 0.8–1.5、左栏收起状态记忆。
  - 只读，不发送对局操作。默认不启用（在模组列表里打开），`config.json` 的 `Enabled` 改动立即生效；手牌服务默认开启，会把本局观战码发给 `HandServiceUrl` 配置的第三方观战服务。
- **关键筹码置顶（PinnedRelicsMod 1.2.2）**：持有名单内筹码时，在玩家信息栏星币下方横排显示游戏原生图标与品质底圈；`pinnedRelicNames` 可配置中文名与顺序，另有图标尺寸、间距与偏移选项。修复单个图标加载失败会连累其余图标、以及战斗 HUD 尚未生成时找不到面板的问题。

### 界面与选项

- `CombatOddsMod`：对外提供结构化战斗读数 `BattleOddsFeed`，其他 mod 可自行排版显示，并可用 `ClaimDisplay()` 接管战斗窗口读数框（3 秒无声明后自动恢复）；新增 `LabelBackground`（棋盘头顶小标签加深色底）与 `AtkBonusIcons`（HUD 攻击力旁按加攻筹码显示图标 +N）；修复关闭 `LabelBackground` 后旧底块不消失。
- `TurnClockMod`：每回合只保留一个补偿窗口，避免多个窗口叠加。

### 构建与打包

- 热更侧对可能被裁剪的 BCL 成员的调用全部隔离成独立方法，避免在调用点抛出；新增 `tools/check-hotupdate-apis.ps1`，`stage-modloader-dist.ps1` 打包前强制扫描。
- `tools/package-modloader.ps1` 补齐模组的 `data/` 目录：进入发布包并写入 SHA256 清单。

## [3.7.3] - 2026-11-12

### 修复：3.7.2 的模组全部起不来

- 3.7.2 加的"游戏程序集版本闸门"在**热更环境里读不到程序集身份**（HybridCLR 裁剪了 `Assembly.ManifestModule`），一读就是 JIT 期抛 `MissingMethodException`，异常从模组入口逃出去，结果 25 个模组里 23 个直接起不来（`entry failed: run_entry: MissingMethodException: MethodNotFind System.Reflection.Assembly::get_ManifestModule`）。
- 3.7.3 **移除了这个运行期闸门**：热更环境里不做程序集比对，模组照常启动。
- 换来的是三层兜底：① **回调护栏**——模组自己的 RPC 回调抛异常只记一次日志，绝不逃进游戏的回调链（不会把整局卡死）；② **打包期校验**——换了游戏程序集却忘了同步标记，直接拒绝出包；③ 每次游戏热更都要**重编译全部模组**。
- 3.7.2 里另外那些有效的东西（回调护栏、SDK 事件回调的首次异常日志、20:30 热更的适配）都保留。

## [3.7.2] - 2026-11-12

### 适配 20:30 的第二次热更

- 游戏在 20:30 又推了一次热更（换了热更程序集、新增角色美术与骰子、配置表微调，约 69 MB）。
- 本包的**游戏程序集闸门标记同步更新**到这个版本；3.7.1 的标记是按上一版热更程序集记的，装到新游戏上会被判成"程序集不匹配"而把所有模组都跳过。
- 顺带说明：这次热更里，游戏把卡牌图鉴窗口销毁时的空引用补上了（此前会导致进图黑屏），本包的回调护栏仍然保留作为兜底。

## [3.7.1] - 2026-11-12

### 修复：模组异常会让整局游戏卡住

- **模组自己包的 RPC 回调现在都会兜住异常**：异常只在日志里记一次，不再逃进游戏的回调链。之前只要游戏更新删掉了模组用到的协议成员（例如移速 Buff 的明细），模组的回调就会在游戏的掷骰/回合链上抛异常，**整局游戏会卡住**（画面还能拖动，但怪物不动、回合不走，另一边的血条也对不上）。
- SDK 自带的事件回调也从"静默忽略"改成"记一次日志"，出问题时能看到具体是哪条事件。

### 新增：游戏程序集版本闸门

- 加载器会核对**运行中的游戏热更程序集**与**本包编译时用的那一份**是不是同一个（用程序集版本标识比对，主版本号相同但热更程序集换了也算不匹配）。
- 不匹配时**所有模组都不会启动**，日志里写明原因。这样"游戏更新了、模组包没更新"不会再变成"进游戏就卡死"，而是变成"模组不加载，游戏照常玩"。
- 打包时会校验这个标记，写错就直接拒绝出包。

## [3.7.0] - 2026-11-12

### 20261112游戏更新

- 适配 2026-11-12 游戏热更：更新编译期引用的游戏程序集，内置模组在新版游戏上正常工作。
- `CombatOddsMod` 2.8.6：移除移动速度预测（游戏未提供逐条移速数据），其余读数与显示保持不变。
- `CardSkinMod` 1.2.2：修复卡牌图鉴页面的卡面替换路径。
- 默认卡面包补齐新增卡牌（`UT_HandCard_21030`、`UT_HandCard_21031`），共 198 张。

## [3.6.0] - 2026-11-10

### Unity 加速与回合时钟

- SpeedHackMod 新增 `accelerationMode=unity`，通过 Unity 时间缩放加速，原有 `native` 模式继续保留；缺少该配置项时仍使用 `native`。
- Unity 模式同步 FairyGUI 界面、独立计时动画、镜头切换与可适配的静音 UI 视频；静音视频最高 3 倍，带音轨或音轨信息未知的视频不强行改速。
- 新增固定更新步长优化，可通过 `optimizeFixedUpdates` 关闭；切换模式、恢复 1 倍或卸载时释放本模组仍持有的动画与时间设置，不主动解除游戏暂停。
- TurnClockMod 适配 Unity 与原生组合倍率，按计时器使用的时间来源补偿自己的操作倒计时、选人、结算、房间等待与剧情自动播放。

### 变速与控制台

- 变速控制改用每进程独立的本机 UDP 端口，设置请求与实际倍率回执均不再使用共享通信文件；多开时互不串号。
- SDK 新增 `SpeedHack.TryGetSpeed`，区分已确认倍率与未知状态；SpeedHackMod 和 TurnClockMod 使用 UDP 状态确认，兼容倍率切换、请求重试及回执过期。
- 控制台标题显示加载器版本与构建时的 Git 短哈希，进入或退出 Debug Shell 时保留版本标识；包含未提交源码更改的构建附带 `-dirty` 标记。
- 升级时需同时更新原生加载器、SDK、SpeedHackMod 与 TurnClockMod；旧文件通道不再作为备用通道，现有倍率与热键配置保留。

## [3.5.2] - 2026-11-09

### 多开

- **修复多开共图冷启时地图加载偶发停在 90%**：多个实例共用同一份地图资源、冷启第一次进图时同一缓存文件会被同时打开，打开失败会让加载直接停在 90% 且需重启进程才好。加载器现在对这类瞬时占用自动重试，加载过程可继续进行；失败与恢复状态会写入加载器日志（`bundle CreateFileW`），便于排查。设置与用法不变。

### 内置模组

- **`CombatOddsMod` 2.8.4**：梅加斯理论伤害读数与玩家头顶攻防标签新增位置/字号微调（`MegasDamageOffsetX/Y`、`MegasDamageFontSize`、`PlayerAttrOffsetX/Y`、`PlayerAttrFontSize`），在 Toys 配置中调整后热重载生效；默认与旧版位置、字号一致。

## [3.5.1] - 2026-11-08

### 变速引擎：修复高频时钟调用下的无响应

- **修复变速时钟的全局自旋锁（关键）**：虚拟时钟状态原本用 56 字节的 `TimeState` 整体做原子拷贝，MSVC 里超过 16 字节的 atomic 拷贝要走全进程共用的自旋锁（`_Atomic_lock_acquire`）。游戏高频调用 `QueryPerformanceCounter` / `GetTickCount`，几十个线程会排在同一把锁上自旋，主线程饥饿后任务管理器显示未响应，画面冻结但声音还在。现把状态拆成逐字段的 ≤8 字节无锁原子，hook 入口不再取锁；切速顺序（基准先行、速度最后发布）保证撕裂读误差只有微秒级，变速手感与连续性不变。
- **建议**：从 3.5.0 以前版本升级的用户，若曾在战斗中遇到“画面冻住、声音还在”的无响应，升级到 3.5.1 后正常对局不应再复现；倍率与时钟行为不变。

## [3.5.0] - 2026-11-08

### SDK：玩家与对局上下文

本版新增均为只加不改：不改现有方法签名、不改现有事件语义与触发条件，旧 mod 无需重新编译即可继续运行。

- **名册**：`PlayerStat` 新增 `Slot`（座位号，0 起，异常时按名册顺序兜底）与 `Character`（角色名，缺失为空串）。
- **模式分数**：新增 `Players.Score(playerId)`，读取当前 `SpecialScore`，查不到返回 0。
- **对局上下文**：新增 `Players.TryGetMatch(out MatchInfo)`，一次拿到是否在有效对局、房间 id/开始时间（两者同时不变视为同一局）、地图模式与是否 PVE/已入战斗；大厅与战斗未就绪时返回 `false`。
- **名字开关**：`Names.Card/Relic/Skill` 新增 `(id, withId)` 重载，`withId=false` 只返回名字；原单参签名与输出保持不变。
- **配置读取**：新增 `ConfigReads.SkillParam(skillId, index)`（越界/缺失返回 `-1`）与 `ConfigReads.RelicQuality(relicId)`（0=无/1=蓝/2=紫/3=橙）。
- **商店单价**：`ShopOffer` 新增 `UnitPrices`，与卡牌逐张对齐（未知为 `-1`，PVP 恒 `-1`）。

### SDK：结算、追击与累计步数

- **完整血量**：新增 `GameEvents.HeroHpChangedFull`（`HeroHpChangeInfo`，含归属与原始值），与旧 `HeroHpChanged` 并行广播；`RealHp == 0` 表示未提供。
- **结算数据**：新增 `GameEvents.MatchSettled`（每人 `PlayerFinalStats`，服务器最终值），只做对账不覆盖本地累计。
- **追击快照**：新增 `GameEvents.FightResolved`（`FightSnapshot`），按 `BattleId` 去重推送攻防/追击归属。
- **累计步数**：新增 `GameEvents.MovementTotalChanged` 与 `GameEvents.MovementTotal`（按到达确认计数，查不到返回 `-1`）。

### 内置模组

- **新增 `MapPeekMod`（选人地图预览）**：选人/选皮肤/准备阶段在左上角显示本局地图名、地图 ID、模式、难度与人数，开赛后自动隐藏；纯只读。
- **`ShopRelicPeekMod` 1.3.0**：商店/筹码看板每条信息追加相对时间（`刚刚 / Xs前`，可分别开关）；玩家名后显示所选角色名（可关）；修复离店不自动关闭：PVP 空包关店、PVE 回执 `IsClose`、商人快照直达离店倒计时、新回合强制离店与在店保底过期（`max(60, 3×时长)`）共同兜底，`Sn` 去重避免重复广播复活已离店条目。

## [3.4.0] - 2026-11-08

### SDK：对局观测事件

`GameEvents` 新增商店成交、筹码刷新、血量差值与击杀等事件，并改为按需挂钩：只有存在订阅者的 RPC 才被包装，订阅者清空后还原原回调。

- **商店成交**：新增 `GameEvents.ShopSettled`，参数 `ShopSettlement`，覆盖 PVE 5216 与 PVP 5030。提供本次实际购买的槽位、成交消息自带的卡牌、已买标记、离店状态、PVE 转账目标与下行序号；`ResolveBoughtCardIds()` 把槽位下标换算成卡牌配置 id。
- **商店报价**：新增 `GameEvents.ShopOffered`，参数 `ShopOffer`，在 `ShopCandidates` 的卡 id 列表之外保留原价、折扣价、免费、已买与转账字段；`TotalGold` 返回应付款（有折扣时取折扣价）。
- **筹码候选与结果**：新增 `GameEvents.RelicOffered`（`RelicOffer`，含 `Sn`、`IsReroll`、`Lv`、`SupLv`）与 `GameEvents.RelicResult`（`(playerId, relicId, isReroll)`）。`RelicSelected` 保持“只报真正选定”的原有语义。
- **筹码刷新次数**：新增 `GameEvents.RelicRerollChanged` 与 `GameEvents.RelicRerollRemaining(playerId)`；查不到时返回 `-1`。
- **血量与击杀**：新增 `GameEvents.HeroHpChanged`（差值为正可负）与 `GameEvents.PlayerKilled`（`victimId, attackerId`）。
- **下行序号**：新增 `GameEvents.DownSn(int command)` 与 `GameEvents.DownSn(RPCMsgManager, int)`，配合 `GameCommands` 常量在结果事件里同步读取对应消息的下行序号，用于和候选 action 的 `Sn` 对账。
- **挂钩行为**：`StartAutoHook()` 仍可一次启动内部维护；所有事件改为逐订阅者 `try/catch`，单个 mod 抛异常不影响游戏与其它订阅者。已有事件签名与语义保持不变。

### SDK：uGUI 控件封装（WidgetService）

- 新增 `WidgetService`（`Canvas` / `Panel` / `Text` / `Slider` / `Badge` / `Anchor` / `Stretch` / `Place` / `Destroy` / `DestroyAll` / `EnsureEventSystem`）：SDK 编译期只引用 `UnityEngine.CoreModule`，运行时按名解析 uGUI 类型，缺失时返回 `null` 并在 `UnavailableReason` 给出原因；所有创建/销毁/改属性自动切主线程。`WidgetHandle` 暴露 CoreModule 的 `Rect`（`RectTransform`）与底层 `Component`，常用操作走 `SetText` / `SetValue` / `SetColor` / `SetActive` / `SetRaycastTarget` / `SetSize` / `SetAnchoredPosition`；`WidgetScope` 记录根节点，`Dispose()` 逆序销毁，配合 `ctx.RegisterCleanup` 保证卸载清理。用法见 `docs/SDK-UI.md` 第 9 节。
- 新增源码示例 `WidgetProbeMod`：在屏幕右上角用 `WidgetService` 画一个常驻 HUD 面板，订阅本版全部新事件（商店报价/成交、筹码候选/结果、刷新余量、血量差值、击杀）并把原始字段与名字渲染到面板上；`F9` 显隐、`F8` 清空。该示例不随加载器内置包分发。

## [3.3.2] - 2026-11-06

### 窗口置前：改用每进程独立 UDP

- 回合置前 / 窗口置前不再走共享文件通道（`request.txt` / `state.txt`），改为原生 `windowctl` 监听 `127.0.0.1` 随机端口，端口经 `CESIUM_FOCUS_PORT` 发布，SDK 以 UDP 发送；多开同机多个实例互不串扰。

### 回合时钟

- 选人后加载地图期间计时器待机，不会误触发超时判定。

### 内置模组

- 移除 `CharacterSkinMod` 的内置分发（源码保留），内置 mod 数由 21 降为 20。

## [3.3.1] - 2026-11-05

### TapTap 启动绕过

新增 TapTap PC 独立客户端检测绕过支持，可直接启动游戏主程序而无需拉起 TapTap 客户端：

- **`tapTapBypassEnabled`**（默认 `false`）：主开关。拦截 `TapClientStandalone` 与 `TapCoreStandalone` 的 `IsLaunchedFromTapTapPC` 检查并返回已就绪的成功结果。
- **`tapTapBypassRestartCheck`**（默认 `false`）：为 `taptap_api.dll` 中的 `TapSDK_RestartAppIfNecessary` 挂载桩函数，恒返回 0，防止进程拉起外部客户端并退出。
- **`tapTapBypassLogin`**（默认 `false`）：为 TapSDK 相关鉴权 API（`TapSDK_Init`、`TapUser_AsyncAuthorize`、`TapSDK_GetClientID`、`TapUser_GetOpenID`）提供安全返回的桩函数。

## [3.3.0] - 2026-11-05

### 多 profile

- **窗口标题带上 profile 名**：同时开多个实例时，游戏窗口标题会追加当前 profile 名（如 `吉星派对 · P2`），在任务栏和 Alt+Tab 里一眼区分。默认开启，可用 `profileWindowTitle` 关闭；只在配置了 `profile` 时生效，绝对路径形式的 profile 只显示目录名。
- 游戏重置窗口标题后加载器会自动补回后缀，不会重复叠加；写入标题不改变窗口大小、位置或焦点。
- AstralParty.Toys 的「游戏多开」页新增同名开关，安装或更新加载器时会把缺失的 `profileWindowTitle` 补进已有配置，注释与用户已有值保留。

## [3.2.0] - 2026-11-04

### SDK：匹配与选人 API

- 新增事件 `GameEvents.MatchSuccess`、`HeroSelectionStarted`、`HeroSelected`，覆盖匹配成功、进入选人界面与角色确认结果。
- 新增 `GameEvents.EnsureRoomHooked()`：匹配/选人消息在战斗之外到达，由 SDK 单独挂钩，`StartAutoHook()` 已包含。
- 新增操作 `GameActions.CanSelectHero`、`GameActions.SelectHero(int heroId)`、`GameActions.ConfirmHero(bool auto = false)`。
- `TurnFocusMod` 改用 SDK 的统一匹配成功事件，不再自行包装对应 RPC。
- 新增源码示例 `HeroAutoSelectMod`：进入选人阶段后自动选择指定角色并确认，默认角色 102。该示例不随加载器内置包分发。

### 战斗胜率助手（CombatOddsMod）

- **手牌概率预览**：出牌阶段在手牌上显示每张可用战斗牌的概率。攻击牌显示打出后的击杀率，防御牌显示打出后的存活率，两者都以防守方选择防御为条件，出牌结果同步后自动重算。
- **固定点数牌**：支持暗影突袭、蓄力、全力攻击与龙之咆哮等固定点数牌；全力攻击的最终攻击倍率最多生效一次，龙之咆哮会降低目标基础防御。
- **显示调整**：新增 `HandOddsFontSize`、`HandOddsOffsetX`、`HandOddsOffsetY`，分别调整手牌概率的字号与横纵位置。

## [3.1.4] - 2026-11-04

### 战斗胜率助手（CombatOddsMod）

- **出牌实际点数动态重算**：在战斗投牌结算前，出牌结果同步后若能匹配实际牌点（普通攻防牌），预测面板会自动使用已确认的牌点收窄攻防范围，重算预计伤害与击倒率。
- **状态提示**：计入实际出牌点数后，面板显示「已计入实际牌点」；未结算或无法匹配的牌点继续沿用原有的预测范围与判定骰。

## [3.1.3] - 2026-11-04

### 启动与主线程调度

启动阶段的等待与调度做了收敛，体感上主要体现在进入游戏与切换界面时：

- **共享就绪探测**：所有模组共享一次「游戏已可玩」的探测，不再每个模组各跑一份轮询；日志里只会出现一条 `游戏已就绪: 启动门等待 …`。
- **各自上限继续生效**：每个模组仍按自己的等待上限初始化，不会被等待时间最长的模组拖住。
- **兜底不卡死**：探测若提前结束（异常、主线程泵尚未就绪），等待中的模组会直接在自己的上限处继续初始化，不会停在启动门。
- **主线程识别自愈**：主线程 ID 只从 UniTask PlayerLoop 或帧泵线程确认；记录不正确时会自动更正，避免误把后台线程当主线程后出现调度延迟。
- **主线程调度自等待保护**：若等待排空的线程本身就是主线程，超过 100 ms 立即放弃并报告，不再等到超时让画面停住。

### 原生音频通道改为硬编码关闭

- 原生音频服务（UDP 端口 + `<audio>` 文件通道 + MCI 播放）改由加载器代码常量控制，当前固定关闭；`doorstop_config.json` 的 `audioControlEnabled` 仍会被读取与保留，但不再决定是否启动。
- 影响：**自定义音效 / BGM 替换不可用**（例如 AudioSkinMod 的音效方案）。游戏本体的音乐与音效不受影响。
- 加载器通过 `CESIUM_AUDIO_ENABLED` 告知 SDK 真实状态，并清理上一次运行遗留的 `port.txt` / `state.txt`，避免音效请求发往旧端口后静默丢失。
- 调试 Shell 中执行 `set audioControlEnabled true` 会提示该通道已在代码中关闭。

### 音频子系统开销

- 原生音频控制通道改为事件驱动（目录变更通知 + 兜底周期重读），空闲时不再持续打开请求文件；通知句柄创建失败的目录自动退回轮询读取。重复播放同一音效时复用已加载的 MCI 槽位。
- SDK 侧：未注册任何替换规则且没有事件订阅者时，声音事件直接放行；`configId → 事件名/事件 ID` 的结果做缓存；替换规则查询改为无锁读取；Unity 音频接口绑定日志只输出方法数量，不再拼接全部方法签名。

### 内置模组

- **角色半透明（CharacterTransparencyMod）**：按住热键时不再每帧遍历角色层级，只维持已修改过的渲染器透明度，降低持续按住时的开销。
- **星币商店助手（StarCoinShopMod）**：缓存 UI 管理器查询，并在面板关闭时释放，减少每帧重复查找。

## [3.1.2] - 2026-11-03

### 新增内置模组：商店与筹码看板（ShopRelicPeekMod）

在游戏画面右上角独立显示商店货架与筹码选择动态：

- **商店货架实时看板**：
  - 当任意玩家进入商店时，实时展示当前货架上的 4 张卡牌（附带星币费用）。
  - 当货架卡牌被购买时，实时标红提示 `(已售)`。
- **筹码选择与刷新追踪**：
  - 当任意玩家进入筹码选择时，实时展示当前轮次的 3 枚候选筹码。
  - 支持追踪多轮刷新历史，保留刷新前的候选记录；选定筹码后高亮展示最终结果并在保留指定时长后自动隐藏。
- **双看板独立排版与动态避让**：
  - 商店信息与筹码信息采用双层独立看板排版，互不遮挡；当两侧高度重叠时自动执行垂直动态避让。
- **一键清空热键**：
  - 默认按 `T` 键可立即清空并隐藏当前所有看板信息，在处于聊天框输入或文本输入聚焦时不响应热键。
- **坐席颜色区分**：
  - 玩家名称与序号按官方一至四楼经典配色（红、绿、蓝、黄）着色，辨识直观。
- **完整多语言配置**：
  - 随包配置带完整多语言注释（简中、繁中、英文、日文），Toys 玩具页可直接捕获修改快捷键与各项显示开关。

## [3.1.1] - 2026-11-03

### 新增内置模组：角色半透明助手（CharacterTransparencyMod）

- 按快捷键 `H`（默认）使游戏中的角色半透明化（默认 36% 不透明度），方便在角色堆叠或处于关键地块时清晰查看下方地块图标、事件与怪物信息。
- **触发模式开关**：提供 `holdMode` 开关，支持「长按切换」（按住半透明、松开恢复）与「点击切换」（按一次开启、再按一次恢复），默认为长按模式。
- **自定义不透明度**：支持在配置中自定义目标不透明度（`opacity`，范围 0.0 ~ 1.0 或 0 ~ 100%）。
- **技能兼容与透明度还原**：松开或切回时精准还原角色原本的透明度，与角色隐身技能（如邦妮、修女）互不冲突。
- **输入保护**：处于聊天输入框或文本聚焦状态时不响应热键。
- 随包配置带完整多语言注释（简中、繁中、英文、日文），Toys 配置界面可直接捕获修改快捷键与参数。

### SDK 路径服务（CesiumLoader.SDK.IO.Path / SdkPath）

- **统一路径发现**：提供 `GameDirectory`、`LoaderDirectory`、`ModsDirectory`、`ConfigsDirectory`、`LogsDirectory`、`SkinsDirectory`、`AudioDirectory`、`SpeedDirectory`、`WindowDirectory` 等属性，由加载器与环境变量直接协商，告别易失效的反射与相对路径猜测。
- **便捷定位与子路径拼接**：提供 `GetGamePath(...)`、`GetLoaderPath(...)`、`GetModDirectory(...)`、`GetModPath(...)`、`GetModDataPath(...)`、`GetModConfigPath(...)`、`GetSkinPath(...)`、`GetAudioPath(...)` 等 API，支持一键拼接模组目录、数据目录与资源文件。
- **免冲突门面**：
  - `CesiumLoader.SDK.IO.Path`：包含全套路径属性、查找方法与常用 `System.IO.Path` 转发（如 `Combine`、`GetFileName` 等），模组无需额外引用 `System.IO`。
  - `CesiumLoader.SDK.SdkPath` 与 `CesiumLoader.SDK.IO.Paths`：提供根命名空间和复数别名，在同时使用 `System.IO` 时彻底避免类名歧义。
- **目录安全保障**：内置 `EnsureDirectoryExists(...)` 与 `SanitizeFileName(...)`。

## [3.1.0] - 2026-11-03

### 新增内置模组：星币商店助手（StarCoinShopMod）

- 在主界面商城「星币商店」标题旁添加「一键购买」按钮，按槽位顺序自动购买并领取商品。
- 自带冷却间隔保护（默认 0.5 秒），防止快速点击触发请求并发丢单。
- 模组配置中提供 8 个槽位的独立开关（`buySlot1` 至 `buySlot8`），默认启用 1、2、7、8 号槽位，可根据需求在配置界面灵活开启或关闭。
- 完整支持多语言配置项说明与注释。

### 战斗胜率助手（CombatOddsMod）怪物防守建议修正

- 修正怪物作为防守方时的策略提示：当防守者为怪物时，不再提示「建议防守」或「建议躲避」，保持提示逻辑与战斗实际参与者一致。

### 音频子系统与运行时音效替换

- SDK 接入独立音频子系统，提供更可靠的音频播放、音效截获与运行时资源替换能力。
- 随包内置 AudioSkinMod，支持对游戏内置音效进行无感替换。

## [3.0.0] - 2026-11-02

### 模组启动门（就绪即启动）

将原先模组启动时的固定 30 秒等待调整为启动门就绪判定，大幅加快模组初始化速度：

- 游戏进入可玩场景（主界面、战斗、单人等）且主界面或 UI 面板打开后即判定为就绪，稳定 1 秒后立刻初始化全部模组，不再需要盲等 30 秒。
- 模组原有的 `delayMs`（默认 30 秒）现在作为等待上限兜底；若因特殊原因未触发就绪判定，到达上限后仍会正常触发初始化。
- 探测过程全程采用只读检查，不会触发单例提早构造。
- 环境变量选项：若需要恢复旧版的固定等待行为，可设置 `CESIUM_MOD_BOOT_GATE=0`。

### 战斗胜率（CombatOddsMod）性能优化与生命周期管理

- 优化战斗胜率与攻防加成面板的计算路径，减少每帧与每回合的堆内存分配。
- 规范模组生命周期监听清理，在战斗结束与场景切换时集中释放事件与状态缓存。

### 命令行工具（apcsm）支持通过 NuGet 安装

CesiumLoader 脚手架与打包工具已发布至 NuGet（包名 `apcsm`），可作为 .NET 全局工具直接安装与升级：

```shell
dotnet tool install -g apcsm
dotnet tool update -g apcsm
```

支持快速创建新模组项目（`apcsm new`）、编译（`apcsm build`）与打包分发（`apcsm package`）。

## [2.9.2] - 2026-11-01

### 新内置模组：PVE 波次预告

在 PVE 合作挑战中把「任务波次」的刷新回合、波次标题和怪物名单画到地图上。

- 覆盖全部 PVE 地图与难度：82007 / 82008 / 82010 / 82012 / 82013 / 82014 / 82015 / 82016 / 82017。
- 按回合显示波次标题与刷新内容，例如「第 3 回合：孩子王嘎呜登场，刷新 1 个采集小熊，1 个闹钟猫头鹰」。
- 有精确地块时，按地块显示分配到的那只怪，并按类别区分：
  - `首领·孩子王嘎呜`
  - `精英·采集小熊`
  - `普通·闹钟猫头鹰 ×3`
- 配置没有给出精确地块时，只标出该地图的怪物地块并注明「位置随机」，不会把整波名单贴到每个地块。
- 左上角显示本局完整波次列表，当前进度高亮。
- 默认关闭；进入 PVE 后按 `O` 打开或关闭。聊天输入框获得焦点时不会误触。
- 地图标记比岔路地块标记更高，并可在配置里用 `labelLift` 继续调整。

配置项：`enabled`（默认 `false`）、`toggleKey`（默认 `O`）、`fontSize`、`heightOffset`、`labelLift`、`showSchedulePanel`、`showOnlyNextWave`、`showRandomLandHints`、`maxWaves`。

内置模组同步到 17 个。

## [2.9.1] - 2026-10-31

### 回合时钟：选人、结算、房间等待与剧情自动播放

变速会把引擎里的倒计时一起加速，回合时钟现在把这些界面上的倒计时也按真实时间走：

- **选人界面**（选英雄、选皮肤）：到点不再提前自动确认；
- **结算界面**：自动翻页按真实时间走，战报可以看完；
- **房间等待**：等待超时不再提前退出房间，房主也不会提前把房主转给别人；
- **剧情自动播放**：翻页按真实时间走，想让它跟着变速跑可以在配置里关掉。

每处都有独立开关（`heroSelect` / `settlement` / `roomWait` / `storyAuto`，默认开启），旧配置在首次启动时自动补齐这四个开关。动画、战斗表演、其他玩家回合与 PVE 怪物回合仍按你设置的倍率加速。

### 战斗胜率：移动速度加成

- 新增可选显示（默认关闭）：自己角色卡「查看筹码」按钮正上方，以及棋盘上每名玩家头顶的攻防标签里带上移速加成，例如 `移速+2`、`攻 6  防 4  速 +2`。
- 预测会累加已知的移速来源：筹码常驻、技能与道具 Buff（含 `下次移动速度±N` 这类一次性效果）、服务器推送的临时加减速，以及按层数或条件计算的条目。服务器每次移动顺带下发的各 Buff 实际贡献会覆盖本地数值。
- 客户端读不到来源的常驻加成（建筑效果、隐藏被动等）会自动校准：连续两次投骰的「实际 − 预测」一致时，把差额并入之后的预测。
- 观战与回放显示当前查看玩家的数值；PVP 没有「查看筹码」按钮，角色卡读数放在防御数字右侧。
- 配置项：`ShowMoveBonus`（默认 `false`）、`MoveBonusFontSize`、`MoveBonusOffsetX` / `MoveBonusOffsetY`、`LogMoveBonusDetail`。

## [2.9.0] - 2026-10-31

### 调试 Shell

控制台里的 `cesium>` 提示符现在按常见 shell 的方式编辑：

- `←` / `→` 移动光标，`Ctrl+←` / `Ctrl+→` 按词移动；`Home` / `End`（或 `Ctrl+A` / `Ctrl+E`）跳到行首 / 行尾。
- `Backspace` / `Delete` 删光标前 / 光标处的字符；`Ctrl+Backspace` / `Ctrl+Delete` 按词删除。
- `Ctrl+W` 删前一个词，`Ctrl+K` 删到行尾，`Ctrl+U` 删到行首，`Ctrl+Y` 粘回刚删掉的内容。
- `↑` / `↓` 翻历史命令；翻历史前没提交的内容会保留，翻回最新时恢复。
- 命令较长、输入折行时，光标仍然停在正确的字符位置。

### Tab 补全

- 第一个词补全命令名：`statu` + `Tab` → `status`。
- `help` 后面补全命令名。
- `get` / `set` / `ls` 后面补全配置键：`get loader.consoleT` + `Tab` → `get loader.consoleTopmost`。
- 只有一个候选时直接补齐并补一个空格；有多个候选时先补公共前缀，再按 `Tab` 在下方列出全部候选。
- 引号里的内容不补全。

### 控制台日志

- 模组日志转发到控制台时按级别着色：`DBG` 暗灰、`INF` 默认灰白、`WRN` 黄色、`ERR` / `FTL` 红色；时间戳与级别保持暗灰。
- 日志文件内容不变，仍是纯文本。

### 发布包

- 加载器包新增 `CesiumLoader-NOTICE.txt`（版权、许可与免责声明）和 `CesiumLoader-LICENSE.txt`（AGPL-3.0 全文）。
- 两个文件会同时出现在游戏 exe 目录（`version.dll` 同级）和 `AstralParty_ModLoader` 目录；安装或使用即表示同意该许可。

## [2.8.11] - 2026-10-30

- 修复「多语言支持」在游戏设置里的入口：
  - 国服客户端的画面页按区域控制器隐藏了语言行，之前只能在模组 `config.json` 里改语言，设置界面看不到入口。
  - 现在打开「设置 → 屏幕」会显示完整的语言行（标题 + 下拉框），可选简体中文 / 英文 / 日文 / 繁中，确认后重新登录生效。
- 多语言数据与切换逻辑不变：国服未翻译的内容保持简中，首页横幅沿用国服素材。

## [2.8.10] - 2026-10-30

- 新增内置模组「多语言支持」（LanguageUnlockMod）：
  - 国服客户端在「设置 → 屏幕 → 语言」里启用 **英文 / 日文 / 繁中**；国际服原生支持这 4 种语言，模组检测到后不介入。
  - 切换后界面文案与卡牌、技能、道具、剧情等正文同步切换；选择写入模组 `config.json`，下次启动自动应用。
  - 国服尚未翻译的内容保持简中，不会出现空白；字体使用游戏自带资源，切换前会预检，取不到时回退简中字体。
  - 首页横幅沿用国服素材，避免外语横幅图缺失导致的空白。
- 新增内置模组「帧率解锁」（UnlockFrameRateMod）：
  - 在游戏「设置 → 屏幕 → 帧率」下拉框里追加 **144 / 165 / 240 / 360 / 不限帧** 五个选项，选中后由游戏自己应用并保存。
  - 原生 30/60/90/120 选项不变；游戏重建配置表后会自动补回追加项。
  - 「不限帧」需要关闭游戏内垂直同步（勾选垂直同步时游戏会置灰帧率下拉框）。
  - 关闭模组即恢复原版列表。
- SDK 新增 `CesiumLoader.SDK.Engine.UnityFrameRate`：`Target`、`VSync`、`SetTarget`、`SetUnlimited`、`SetVSync`、`Describe`，用于在运行时读写目标帧率与垂直同步。

## [2.8.9] - 2026-10-30

- 战斗胜率助手（CombatOddsMod）：
  - 攻方投出 0 点时不再被当作“尚未投骰”。摩西【破绽】等把怪物战斗骰点压到 0 时，战斗面板按有效 0 点计算，正确给出闪避必定成功。
  - 攻方尚未投骰时仍按最坏情况（`MaxAtk` 加判定骰）估算，不会把未投出的 0 当成已投出的点数。
- SDK 新增战斗子阶段：
  - `GameEvents.CurrentBattlePhase`、`GameEvents.AttackerHasRolled`、`GameEvents.AttackerPoint` 区分“骰子尚未落地”与“投出 0 点”；`AttackerPoint` 未投骰时为 `-1`。
  - 新增 `GameEvents.BattlePhaseChanged` 事件。攻方投出 0 点时战斗数值不变，`BattleUpdate` 会被去重，订阅该事件才能在骰子落地时立即刷新。

## [2.8.8] - 2026-10-30

- 新增内置模组「快捷短语扩展」（QuickChatPlusMod）：
  - 战斗内快捷短语列表补入房间等待、结算与其他模式的既有短语；PVE 列表从 16–19 条扩展到 32 条。
  - 列表超出屏幕时自动限高并支持滚轮或拖动滚动；默认同时显示 16 条，可在 `config.json` 的 `maxVisibleItems` 调整（0–60，`0` 表示按屏幕可用高度尽量多）。
  - 短语文本与发送沿用游戏原版，其他玩家无需安装本模组也能看到；模组只改变本机的列表内容。
  - 战役 PVE、练习 PVE 原本没有快捷短语列表，启用后可以正常打开。
  - 配置项：`enabled`、`includeRoomChats`、`includeResultChats`、`includePvpModes`、`maxVisibleItems`。

## [2.8.6] - 2026-10-28

- 模组配置支持多语言说明：`config.json` 顶层新增保留键 `_comments`，为每个配置项提供简中、繁中、英文、日文说明。
  - Toys 的模组配置弹窗按界面语言显示说明，缺失时依次回退到同语系中文、英文、日文。
  - 第三方模组也可以只写一句字符串，所有语言共用。
  - 说明保存在配置文件末尾，Toys 保存配置时会原样保留；没有说明的旧配置界面保持不变。
- SDK 新增 `ConfigDoc`、`ModConfig.Describe()` 与 `ModConfig.SetDefault(key, value, ConfigDoc)`。模组初始化时补齐说明即可，已有用户值不会被覆盖，旧配置升级后会自动补上说明。
- 全部内置模组补齐配置项说明（简中 / 繁中 / 英文 / 日文），首次进入游戏或打开 Toys 配置页即可看到。

## [2.8.4] - 2026-10-27

- 新增内置模组「隐藏 HUD」：按住反引号键（Tab 上方）隐藏战斗 HUD，松开恢复；也可以改成按一下切换。
  - 默认键 `BackQuote`，长按 0.35 秒触发；`pressMode=Toggle` 改为切换。
  - 手牌、怪物信息、头像与其他 HUD 可分别开关（`hideHandCards`、`hideMonsterDisplay`、`hideAvatars`、`hideOther`），`hideAllHud` 可一键全隐藏。
  - 只改界面可见性，不拦截鼠标键盘，不向服务器发送操作。
- 战斗胜率助手 2.5.0：怪物名字/血量信息条右侧显示主动技能冷却，例如 `CD 2/3`，白字黑描边、字号小于名字。
  - 释放主动技能时取服务器下发的本次冷却，之后每轮 -1；默认只显示 BOSS 与配表里真正带主动技能的怪物，普通/精英的攻击类技能不显示（可用 `ShowMonsterCdForAllMonsters` 打开全部）。
  - 位置可用 `MonsterCdOffsetX` / `MonsterCdOffsetY` 微调。

## [2.8.3] - 2026-10-26

- 新增内置模组「回合时钟」：变速时你自己的操作倒计时仍按真实时间走 —— 2 倍速下 30 秒的回合窗口依旧是 30 秒真实时间，动画、战斗表演、其他玩家回合与 PVE 怪物回合照常加速。
  - 覆盖掷骰、选方向、商店、事件、筹码、战斗出牌/防御等由你操作的窗口。
  - 其他玩家回合的倒计时显示也按真实时间走，可用 `otherPlayers` 关闭。
  - 只在倍率大于 1.0x 时生效；中途改倍率或关掉变速都不会残留状态。
  - 配置：`enabled`、`otherPlayers`、`dryRun`、`logWindow`、`speedRefreshSeconds`，成员名相关键仅在排障时使用。

## [2.8.2] - 2026-10-26

- 战斗胜率助手 2.4.0：左侧玩家栏在主动技能 CD 右侧显示每名玩家的剩余手牌数，图标使用游戏自己的卡牌图标；摸牌、出牌、换牌与净化后自动刷新。0 张时数字显示为暖色。
  - 新增配置 `ShowHandCount`（默认开启）：关闭后不再显示手牌数。
  - 新增配置 `LogHandDetail`（默认关闭）：把每名玩家的手牌数变化写入加载器日志。

## [2.8.1] - 2026-10-25

- 修复随包 `doorstop_config.json` 里的 SDK 版本没有同步到 2.8.0 的问题（仍为 `2.7.2`）：装出来的配置会声明偏低的 SDK 版本，声明要求更高版本的模组可能被误判为不兼容。
- 随包配置模板补上 `debugShell` 项（CesiumLoader Debug Shell，默认开启），新安装可以直接在配置文件里看到这个开关。

## [2.8.0] - 2026-10-25

- 新增 CesiumLoader Debug Shell：在控制台窗口里直接输入命令，查看环境、改配置、看日志，不用改文件或重启游戏。
  - 配置键为 `loader.<字段>` 与 `<ModId>.<键>`，`ls` 列出全部可配置项，`get` / `set` 读写单个键。
  - 命令：`help`、`status`、`env`、`paths`、`mods`、`hooks`、`log`、`proc`、`ls`、`get`、`set`、`reload`、`clear`、`detach`、`exit`。
  - 修改配置立即写盘，保留原有注释与格式，原文件备份为 `.bak`；写盘前重新解析校验。
  - 加载器字段按生效时机区分“立即生效 / 只能开启 / 重启后生效”；模组配置由模组自身热重载。
  - 鼠标滚轮可回看控制台日志；按住左键拖选、右键或 `Enter` 复制，开始输入时视口自动回到底部。
  - 支持 `Ctrl+V` 与 `Shift+Insert` 粘贴；粘贴只填入当前行，不会自动回车执行。
- 新增配置项 `debugShell`（默认开启）：控制台显示 CesiumLoader Debug Shell，可直接查环境、改配置、看日志；设为 `false` 后只显示日志。
- 战斗胜率助手 2.3.9：每次战斗读数的多行框默认不再写日志（`LogBattleOdds`，需要排障时打开）；没有 UI 渲染后端时不再把通知文本镜像进日志。
- `set` 支持数值范围与类型校验，例如倍率拒绝低于 1 倍、超时限制 1–3600。
- 控制台窗口始终由传统控制台承载：Windows 默认终端设置只作用于控制台程序启动时创建的控制台，不会接管加载器后续分配的控制台。

## [2.7.0] - 2026-10-25

- 启动日志重新排版：控制台按窗口宽度折行，续行缩进对齐正文；中英文与 emoji 按两列宽度计算，调整窗口大小后立即生效。
- 日志里的长路径改为 `<loader>\`、`<game>\`、`%LOCALAPPDATA%\` 简写，绝对根目录只在开头打印一次。
- mod 清单与加载结果合并成一张表（序号 / 名称 / 版本 / 结果 / 耗时），去掉重复的 `[i/n]` 编号；`Assembly.Load` 的重载扫描整个过程只报一次结论。
- 变速与窗口置前两个文件通道各合并为一行；倍率统一显示为 `2.0x`；空行不再写入日志文件。
- 新增环境行：游戏版本、Unity 引擎版本（`UnityPlayer.dll`）、进程号与位数。
- `[hijack]` 标签改为 `[loader]`，并区分标题、成功、失败、警告、禁用与路径的配色。
- 原生层日志文本全部改为英文，包含 Steam 绕过各阶段的诊断输出；控制台或管道不可写时改用其他输出方式，重定向到文件时不再丢内容。

SDK 程序集标识保持 2.5.1.0，已安装的 mod 无需重新编译；2.6.x 的配置与模组布局照常读取。

## [2.6.2] - 2026-10-23

- 「回合置前」新增匹配成功触发：游戏显示匹配成功结果时，把游戏窗口切换到前台。
- 「回合置前」新增开房准备触发：匹配成功开房后、游戏开始前的等待阶段，其他玩家发送“准备”之类的房间快捷消息时，把游戏窗口切换到前台。
- 「回合置前」新增 `focusOnMatchSuccess` 与 `focusOnRoomChat` 配置，可分别关闭这两类提示。

窗口已经在前台时请求被静默忽略；回放和观战不触发。

## [2.6.0] - 2026-10-23

- 新增配置热重载：变速、自由相机、战斗辅助、岔路地块标记、自动感谢、手牌查看、诊断工具在游戏运行中修改 `config.json` 后自动应用，无需重启游戏。
- 配置解析支持 `//` 与 `/* */` 注释，Toys 生成的带注释空配置可直接读取。
- 热重载遇到写到一半或损坏的配置时保留当前设置，不覆盖正在编辑的文件；同一份坏内容只提示一次。
- 新增内置模组「回合置前」：轮到自己回合、选择筹码、战斗询问、战斗出牌、攻击骰或防御选择时把游戏窗口切换到前台，窗口已在前台时不打扰；可在配置中开关并调整冷却。
- 新增窗口置前控制文件通道，可在 `doorstop_config.json` 中用 `windowControlEnabled` 关闭。

角色皮肤、卡面皮肤等需要重新加载资源的模组仍需重启游戏后生效。

## [2.5.2] - 2026-10-17

- 战斗辅助的技能 CD 改为直接取服务器推送的冷却消息：每轮按玩家分别更新，释放技能与冷却修正（天赋、遗物、地图效果）即时生效。
- 技能 CD 的冷却上限取该玩家最近一次释放时实际生效的值，强化、天赋与遗物改变上限时同步更新；最终回合的结束标记不再显示成冷却。
- 角色皮肤的动画位移与位置抖动跟随游戏自身的时序与包内原帧锚点。

## [2.5.1] - 2026-10-16

- 战斗辅助在左侧所有玩家头像的昵称上方显示各自技能 CD，冷却上限跟随角色、模式和天赋。就绪显示绿色，冷却中显示黄色，可通过 `ShowSkillCooldown` 关闭。
- 修复战斗辅助配置页为空的问题，启动时补齐缺少的配置项并保留已有设置。
- 修复 SDK 旧式回调入口的 Mod 上下文注册，配置与日志归属对应模组。
- 新增内置岔路地块标记：PVE 三岔路相邻地块按邻接顺序显示红 A、黄 B、蓝 C 与地块 ID，支持配置关闭。
- 控制台遵循 Windows 默认终端设置；传统控制台支持置顶，Windows Terminal 窗口由终端管理。

## [2.5.0] - 2026-10-15

- 适配《吉星派对》3.3.0 / Unity 2022.3.62f3，使用新版游戏程序集重新编译 SDK 和全部 7 个内置模组。
- 修复游戏文本枚举变化导致的卡牌、筹码、技能及占卜名称查询错位。
- 默认皮肤包刷新为 196 张官方卡面，补齐建筑卡及地图事件的普通/SFW 图片；默认皮肤继续作为独立附件提供。
- 角色皮肤适配 Unity 2022 资源基线。
- 修正 CombatOddsMod 的普通攻击预测：普通命中最低造成 1 点伤害。

加载器、默认皮肤与 SDK 工具包各提供版本化文件名及固定文件名，共 6 个附件。
